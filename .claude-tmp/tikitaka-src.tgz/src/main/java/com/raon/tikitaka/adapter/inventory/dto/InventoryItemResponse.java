package com.raon.tikitaka.adapter.inventory.dto;

import com.raon.tikitaka.domain.product.Product;

public record InventoryItemResponse(
        String productId,
        String productName,
        String type,
        boolean isActive
) {

    public static InventoryItemResponse of(Product product, boolean isActive) {
        return new InventoryItemResponse(
                product.getProductId(),
                product.getProductName(),
                product.getProductType().name().toLowerCase(),
                isActive
        );
    }
}
