rootProject.name = "tikitaka"

