package com.raon.tikitaka.application.ranking;

import java.util.UUID;

/**
 * 개인 라운드 랭킹 한 줄 — 네이티브 rank() 쿼리의 인터페이스 프로젝션 (별칭 ↔ getter 매칭).
 */
public interface UserRankRow {

    UUID getUserId();

    String getUserName();

    Integer getUserRank();

    Long getUserScore();
}
