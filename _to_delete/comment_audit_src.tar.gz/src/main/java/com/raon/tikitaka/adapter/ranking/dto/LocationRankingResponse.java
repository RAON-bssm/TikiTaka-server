package com.raon.tikitaka.adapter.ranking.dto;

import com.raon.tikitaka.application.ranking.LocationRankRow;

/**
 * 지역 랭킹 한 줄 — 필드는 API 명세서(/api/location/rank) 그대로.
 */
public record LocationRankingResponse(Long locationId, String locationName, Integer locationRank, Long locationScore) {

    public static LocationRankingResponse from(LocationRankRow row) {
        return new LocationRankingResponse(row.getLocationId(), row.getLocationName(),
                row.getLocationRank(), row.getLocationScore());
    }
}
