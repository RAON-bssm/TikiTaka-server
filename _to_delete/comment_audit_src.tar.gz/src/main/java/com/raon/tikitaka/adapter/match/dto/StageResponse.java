package com.raon.tikitaka.adapter.match.dto;

import com.raon.tikitaka.domain.match.Stage;

import java.time.LocalDateTime;

/**
 * 시즌 및 라운드 조회 응답 — 필드는 API 명세서(/api/match/stage) 그대로.
 * (jackson SNAKE_CASE 전역 설정으로 stageId → stage_id 로 직렬화된다)
 */
public record StageResponse(Long stageId, Integer season, Integer round, LocalDateTime startedAt) {

    public static StageResponse from(Stage stage) {
        return new StageResponse(stage.getStageId(), stage.getSeason(), stage.getRound(), stage.getStartedAt());
    }
}
