package com.raon.tikitaka.application.ranking;

/**
 * 지역 라운드 랭킹 한 줄 — 네이티브 rank() 쿼리의 인터페이스 프로젝션 (별칭 ↔ getter 매칭).
 */
public interface LocationRankRow {

    Long getLocationId();

    String getLocationName();

    Integer getLocationRank();

    Long getLocationScore();
}
