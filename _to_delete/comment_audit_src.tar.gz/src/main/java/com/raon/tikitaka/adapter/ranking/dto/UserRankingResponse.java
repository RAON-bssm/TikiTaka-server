package com.raon.tikitaka.adapter.ranking.dto;

import com.raon.tikitaka.application.ranking.UserRankRow;

import java.util.UUID;

/**
 * 개인 랭킹 한 줄 — 필드는 API 명세서(/api/users/rank) 그대로.
 */
public record UserRankingResponse(UUID userId, String userName, Integer userRank, Long userScore) {

    public static UserRankingResponse from(UserRankRow row) {
        return new UserRankingResponse(row.getUserId(), row.getUserName(),
                row.getUserRank(), row.getUserScore());
    }
}
