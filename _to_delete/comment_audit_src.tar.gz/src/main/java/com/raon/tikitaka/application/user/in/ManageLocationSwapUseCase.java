package com.raon.tikitaka.application.user.in;

import java.util.UUID;

/**
 * 유저의 지역 스위칭 셀프 서비스 — 서브 동네 설정, 예약, 예약 취소.
 * 실제 교환(main ↔ sub)은 라운드 시작 직후 배치(ApplyLocationSwapUseCase)가 수행한다.
 */
public interface ManageLocationSwapUseCase {

    /**
     * 서브 동네 설정/변경. 메인과 같은 동네는 불가(400).
     */
    void setSubLocation(UUID userId, Long locationId);

    /**
     * 스위칭 예약 — 다음 라운드 시작 시 main ↔ sub 교환. 서브 동네가 없으면 400.
     */
    void requestLocationSwap(UUID userId);

    /**
     * 예약 취소.
     */
    void cancelLocationSwap(UUID userId);
}
