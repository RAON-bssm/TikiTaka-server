package com.raon.tikitaka.application.match.in;

import com.raon.tikitaka.domain.keyword.Keyword;

import java.util.List;

/**
 * 미션 재료(키워드) 관리 — admin 전용.
 * 추가/삭제는 다음 매치 생성(라운드 개장)부터 반영된다 — 이미 만들어진 미션은 불변.
 */
public interface ManageKeywordUseCase {

    List<Keyword> getKeywords();

    void addKeyword(String keyword, String type);

    void removeKeyword(String keyword);
}
