package com.raon.tikitaka.application.match;

/**
 * 경기 결과 한 건 — 승패는 조회 시 계산된 값이다 (DB에 win_team을 저장하지 않는다).
 * winTeam/lostTeam이 둘 다 null이면 무승부이거나 BYE(미션 위크) 매치다 — matchType으로 구분.
 */
public record MatchResult(Long matchId, String mission, String winTeam, String lostTeam, String matchType) {
}
