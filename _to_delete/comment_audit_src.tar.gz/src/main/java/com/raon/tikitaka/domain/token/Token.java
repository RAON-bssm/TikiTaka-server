package com.raon.tikitaka.domain.token;

import com.raon.tikitaka.domain.enums.LoginProvider;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "token")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Token {

    @Id
    @Column(name = "user_id", columnDefinition = "uuid")
    private UUID userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "provider")
    private LoginProvider provider;

    @Column(name = "refresh_token")
    private String refreshToken;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public static Token of(UUID userId, LoginProvider provider, String refreshToken) {
        Token token = new Token();
        token.userId = userId;
        token.provider = provider;
        token.refreshToken = refreshToken;
        return token;
    }

    @PrePersist
    public void prePersist() {
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public void updateRefreshToken(String newRefreshToken) {
        this.refreshToken = newRefreshToken;
    }
}
