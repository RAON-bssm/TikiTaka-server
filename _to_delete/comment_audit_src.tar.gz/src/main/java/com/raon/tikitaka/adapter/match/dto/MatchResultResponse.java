package com.raon.tikitaka.adapter.match.dto;

import com.raon.tikitaka.application.match.MatchResult;

/**
 * 경기 결과 한 건 — 필드는 API 명세서(/api/match/result) 그대로.
 * winTeam/lostTeam이 둘 다 null이면 무승부 또는 BYE(미션 위크) — matchType으로 구분.
 */
public record MatchResultResponse(Long matchId, String mission, String winTeam, String lostTeam, String matchType) {

    public static MatchResultResponse from(MatchResult result) {
        return new MatchResultResponse(result.matchId(), result.mission(),
                result.winTeam(), result.lostTeam(), result.matchType());
    }
}
