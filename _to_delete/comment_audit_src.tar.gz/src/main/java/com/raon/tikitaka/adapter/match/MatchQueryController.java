package com.raon.tikitaka.adapter.match;

import com.raon.tikitaka.adapter.match.dto.MatchResultListResponse;
import com.raon.tikitaka.adapter.match.dto.StageResponse;
import com.raon.tikitaka.application.match.in.GetCurrentStageUseCase;
import com.raon.tikitaka.application.match.in.GetMatchResultsUseCase;
import com.raon.tikitaka.global.response.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 시즌·라운드/경기 결과 조회 — URL·응답 형식은 API 명세서를 따른다.
 * 인증은 시큐리티(JWT 필터)가 처리 — 로그인만 돼 있으면 누구나 조회 가능.
 */
@RestController
@RequestMapping("/api/match")
@RequiredArgsConstructor
public class MatchQueryController {

    private final GetCurrentStageUseCase getCurrentStageUseCase;
    private final GetMatchResultsUseCase getMatchResultsUseCase;

    @GetMapping("/stage")
    public ApiResponse<StageResponse> getCurrentStage() {
        StageResponse response = StageResponse.from(getCurrentStageUseCase.getCurrentStage());
        return ApiResponse.of(200, "시즌 및 라운드 조회 성공", response);
    }

    @GetMapping("/result")
    public ApiResponse<MatchResultListResponse> getMatchResults() {
        MatchResultListResponse response = MatchResultListResponse.from(getMatchResultsUseCase.getMatchResults());
        return ApiResponse.of(200, "경기 결과 조회 성공", response);
    }
}
